const data = {
    12: {
        'Fund': {
            'Annualized Return': {'A': 0.15763442379707548},
            'Annualized Volatility': {'A': 0.08946702209172111},
            'Max DD': {'A': -0.035883361921097666},
            'Skew': {'A': 1.0888192127465968},
            'Kurtosis': {'A': 0.15941947771393572}
        },
        'Invested Funds': {
            'Annualized Return': {'B': 0.2209828847109505},
            'Annualized Volatility': {'B': 0.17088326690782488},
            'Max DD': {'B': -0.06660507200000022},
            'Skew': {'B': 1.4545961280186284},
            'Kurtosis': {'B': 1.5090483768853398}
        },
        'Peer Group': {
            'Annualized Return': {'C': 0.1752585570837717, 'D': -0.09569916074655549, 'E': 0.12778841550981124},
            'Annualized Volatility': {'C': 0.13505210256644556, 'D': 0.07383180322658284, 'E': 0.11127329337809891},
            'Max DD': {'C': -0.03213697968738433, 'D': -0.0857382863264002, 'E': -0.05532588110305458},
            'Skew': {'C': 0.850434553488591, 'D': 0.7423022901432851, 'E': 0.26980141455911866},
            'Kurtosis': {'C': 0.4064589457217238, 'D': 0.5034833233888873, 'E': -1.2231028964784296}
        }
    },
    36: {
        'Fund': {
            'Annualized Return': {'A': 0.20364384366735355},
            'Annualized Volatility': {'A': 0.08383676461631617},
            'Max DD': {'A': -0.10712924132672492},
            'Skew': {'A': 1.7321530118276234},
            'Kurtosis': {'A': 3.677588236775697}
        },
        'Invested Funds': {
            'Annualized Return': {'B': 0.4051443327016828},
            'Annualized Volatility': {'B': 0.15915164975283044},
            'Max DD': {'B': -0.2099342813081586},
            'Skew': {'B': 1.3846824080042233},
            'Kurtosis': {'B': 2.1627635306883075}
        },
        'Peer Group': {
            'Annualized Return': {'C': 0.3631327938648903, 'D': 0.06740406730286108, 'E': 0.34034049694917967},
            'Annualized Volatility': {'C': 0.11966014519141638, 'D': 0.07817740947891959, 'E': 0.1378356409956073},
            'Max DD': {'C': -0.092727381190777, 'D': -0.16541722052558816, 'E': -0.14804897119782312},
            'Skew': {'C': 0.4823518659211532, 'D': 0.2836816596975466, 'E': -0.07512702664407904},
            'Kurtosis': {'C': 0.17123296414347777, 'D': -0.2135410827797375, 'E': 0.3374588858908849}
        }
    },
    60: {
        'Fund': {
            'Annualized Return': {'A': 0.639547683378364},
            'Annualized Volatility': {'A': 0.13281191624554092},
            'Max DD': {'A': -0.1071292413267253},
            'Skew': {'A': 4.233558990025668},
            'Kurtosis': {'A': 24.052586925066816}
        },
        'Invested Funds': {
            'Annualized Return': {'B': 1.7865011788193752},
            'Annualized Volatility': {'B': 0.3180548668155932},
            'Max DD': {'B': -0.20993428130815883},
            'Skew': {'B': 5.3038476381046475},
            'Kurtosis': {'B': 34.73837208760681}
        },
        'Peer Group': {
            'Annualized Return': {'C': 0.8099492618614756, 'D': 0.3130991424246512, 'E': 0.6171811988399445},
            'Annualized Volatility': {'C': 0.12918940013100152, 'D': 0.079422329503908, 'E': 0.1511532419435293},
            'Max DD': {'C': -0.14762598935840923, 'D': -0.1654172205255881, 'E': -0.23483206933911166},
            'Skew': {'C': 0.1876297943745428, 'D': 0.3897490157984136, 'E': -0.7420490922597315},
            'Kurtosis': {'C': -0.20606596581820869, 'D': -0.18128114693245267, 'E': 1.690596413464506}
        }
    }
};

// Function to create a box plot for a specific metric
function createBoxPlot(metricData, metric, selector, period) {
    const margin = { top: 20, right: 30, bottom: 40, left: 50 };
    const width = 200 - margin.left - margin.right;
    const height = 200 - margin.top - margin.bottom;

    const values = [
        ...Object.values(metricData['Peer Group'][metric])
    ];

    const min = metricData['Peer Group'][metric]['D'];
    const median = metricData['Peer Group'][metric]['E'];
    const max = metricData['Peer Group'][metric]['C'];

    const q1 = d3.quantile(values, 0.25);
    const q3 = d3.quantile(values, 0.75);
    const interQuantileRange = q3 - q1;

    // Include 'Fund' and 'Invested Funds' values to ensure they are within the y-axis range
    const additionalValues = [
        metricData['Fund'][metric]['A'],
        metricData['Invested Funds'][metric]['B']
    ];

    const y = d3.scaleLinear()
        .domain([Math.min(d3.min(values), ...additionalValues), Math.max(d3.max(values), ...additionalValues)])
        .range([height, 0]);

    const svg = d3.select(selector)
        .append('div')
        .attr('class', 'chart-box')
        .append('svg')
        .attr('width', width + margin.left + margin.right)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`)
        .attr('class', 'boxplot');

    svg.append('g')
        .call(d3.axisLeft(y));

    const center = width / 2;
    const boxWidth = 50;

    svg.append("line")
        .attr("x1", center)
        .attr("x2", center)
        .attr("y1", y(min))
        .attr("y2", y(max))
        .attr("stroke", "black");

    svg.append("rect")
        .attr("x", center - boxWidth / 2)
        .attr("y", y(q3))
        .attr("height", y(q1) - y(q3))
        .attr("width", boxWidth)
        .attr("stroke", "black")
        .style("fill", "#ADD8E6");

    const points = [
        { value: metricData['Fund'][metric]['A'], color: '#ffA500' },
        { value: metricData['Invested Funds'][metric]['B'], color: 'red' },
        { value: max, color: 'black' },
        { value: min, color: 'black' },
        { value: median, color: 'black' }
    ];

    svg.selectAll("circle")
        .data(points)
        .enter()
        .append("circle")
        .attr("cx", center)
        .attr("cy", d => y(d.value))
        .attr("r", 5)
        .style("fill", d => d.color);

    svg.selectAll("toto")
        .data([min, median, max])
        .enter()
        .append("line")
        .attr("x1", center - boxWidth / 2)
        .attr("x2", center + boxWidth / 2)
        .attr("y1", d => y(d))
        .attr("y2", d => y(d))
        .attr("stroke", "black");
}

// Function to create separate charts for each metric and period
function createCharts(data) {
    const container = d3.select('#plot-container');
    
    ['12', '36', '60'].forEach(period => {
        const metricData = data[period];
        const row = container.append('div').attr('class', 'chart-container');
        
        ['Annualized Return', 'Annualized Volatility', 'Max DD', 'Skew', 'Kurtosis'].forEach(metric => {
            const chartContainer = row.append('div').attr('class', 'chart-box');
            chartContainer.append('div')
                .attr('class', 'chart-title')
                .text(`${metric} - ${period} Months`);
            createBoxPlot(metricData, metric, chartContainer.node(), period);
        });
    });
}

createCharts(data);
